package com.bubble.ai;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/** Милый анимированный пузырь-маскот с эмоциями. */
public class BubbleView extends View {
    public static final int NEUTRAL = 0;
    public static final int HAPPY = 1;
    public static final int ANGRY = 2;
    public static final int SAD = 3;
    public static final int SURPRISED = 4;
    public static final int LOVE = 5;
    public static final int SLEEPY = 6;
    public static final int THINKING = 7;

    private int emotion = NEUTRAL;
    private boolean talking = false;
    private final long start = System.currentTimeMillis();

    private final Paint body = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rect = new RectF();

    private static final int DARK = 0xFF22324D;

    public BubbleView(Context c) {
        super(c);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setColor(DARK);
        fill.setStyle(Paint.Style.FILL);
        text.setColor(0xFFFFFFFF);
        text.setFakeBoldText(true);
    }

    public void setEmotion(int e) {
        emotion = e;
        invalidate();
    }

    public void setTalking(boolean t) {
        talking = t;
    }

    public static int emotionFromName(String s) {
        if (s == null) return NEUTRAL;
        switch (s.trim().toLowerCase()) {
            case "happy": return HAPPY;
            case "angry": return ANGRY;
            case "sad": return SAD;
            case "surprised": return SURPRISED;
            case "love": return LOVE;
            case "sleepy": return SLEEPY;
            case "thinking": return THINKING;
            default: return NEUTRAL;
        }
    }

    private void drawHeart(Canvas c, float x, float y, float s) {
        path.reset();
        path.moveTo(x, y + s * 0.35f);
        path.cubicTo(x + s * 0.9f, y - s * 0.3f, x + s * 0.5f, y - s * 0.95f, x, y - s * 0.4f);
        path.cubicTo(x - s * 0.5f, y - s * 0.95f, x - s * 0.9f, y - s * 0.3f, x, y + s * 0.35f);
        path.close();
        c.drawPath(path, fill);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float t = (System.currentTimeMillis() - start) / 1000f;
        float w = getWidth();
        float h = getHeight();
        float cx = w / 2f;
        float cy = h / 2f;
        float r = Math.min(w, h) * 0.40f;

        float wob = (float) Math.sin(t * 2.4f);
        float sx = 1f + 0.035f * wob;
        float sy = 1f - 0.035f * wob;
        float shake = 0f;
        if (emotion == ANGRY) shake = (float) Math.sin(t * 38f) * r * 0.035f;

        canvas.save();
        canvas.translate(shake, (float) Math.sin(t * 1.7f) * r * 0.06f);
        canvas.scale(sx, sy, cx, cy + r);

        // тело
        int c1 = 0xE6FFFFFF;
        int c2 = 0xAA7EC8FF;
        int c3 = 0xCC3FA0FF;
        if (emotion == ANGRY) { c2 = 0xAAFF9A8A; c3 = 0xCCFF4A3A; }
        else if (emotion == SAD) { c2 = 0xAA9FB4D6; c3 = 0xCC6A82B0; }
        else if (emotion == LOVE) { c2 = 0xAAFFC0E0; c3 = 0xCCFF70B0; }
        else if (emotion == SLEEPY) { c2 = 0xAAB9B4F0; c3 = 0xCC7B72D6; }
        body.setShader(new RadialGradient(cx - r * 0.35f, cy - r * 0.4f, r * 1.6f,
                new int[]{c1, c2, c3}, new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawCircle(cx, cy, r, body);
        body.setShader(null);

        // блик
        fill.setColor(0x99FFFFFF);
        rect.set(cx - r * 0.66f, cy - r * 0.74f, cx - r * 0.14f, cy - r * 0.40f);
        canvas.drawOval(rect, fill);

        // лицо
        float ey = cy - r * 0.08f;
        float ex = r * 0.36f;
        float er = r * 0.12f;
        line.setStrokeWidth(Math.max(2f, r * 0.07f));
        boolean blink = (t % 3.8f) < 0.13f;

        // щёчки
        if (emotion == HAPPY || emotion == LOVE || emotion == NEUTRAL) {
            fill.setColor(0x66FF8FA8);
            rect.set(cx - r * 0.74f, cy + r * 0.13f, cx - r * 0.46f, cy + r * 0.31f);
            canvas.drawOval(rect, fill);
            rect.set(cx + r * 0.46f, cy + r * 0.13f, cx + r * 0.74f, cy + r * 0.31f);
            canvas.drawOval(rect, fill);
        }

        // глаза
        if (emotion == HAPPY) {
            for (int sg = -1; sg <= 1; sg += 2) {
                rect.set(cx + sg * ex - er * 1.3f, ey - er * 0.9f, cx + sg * ex + er * 1.3f, ey + er * 1.1f);
                canvas.drawArc(rect, 200f, 140f, false, line);
            }
        } else if (emotion == LOVE) {
            fill.setColor(0xFFFF4D88);
            float hs = er * (1.7f + 0.25f * (float) Math.sin(t * 8f));
            drawHeart(canvas, cx - ex, ey, hs);
            drawHeart(canvas, cx + ex, ey, hs);
        } else if (emotion == SLEEPY) {
            for (int sg = -1; sg <= 1; sg += 2) {
                canvas.drawLine(cx + sg * ex - er * 1.1f, ey, cx + sg * ex + er * 1.1f, ey, line);
            }
            text.setTextSize(r * 0.45f);
            float zy = cy - r * 0.55f - ((t * 18f) % (r * 0.3f));
            canvas.drawText("z", cx + r * 0.55f, zy, text);
        } else if (emotion == SURPRISED) {
            for (int sg = -1; sg <= 1; sg += 2) {
                fill.setColor(0xFFFFFFFF);
                canvas.drawCircle(cx + sg * ex, ey, er * 1.6f, fill);
                canvas.drawCircle(cx + sg * ex, ey, er * 1.6f, line);
                fill.setColor(DARK);
                canvas.drawCircle(cx + sg * ex, ey, er * 0.8f, fill);
            }
        } else {
            fill.setColor(DARK);
            float ox = 0f;
            float oy = 0f;
            if (emotion == THINKING) { ox = er * 0.4f; oy = -er * 0.3f; }
            for (int sg = -1; sg <= 1; sg += 2) {
                if (blink) {
                    canvas.drawLine(cx + sg * ex - er, ey, cx + sg * ex + er, ey, line);
                } else {
                    canvas.drawCircle(cx + sg * ex + ox, ey + oy, er, fill);
                    fill.setColor(0xFFFFFFFF);
                    canvas.drawCircle(cx + sg * ex + ox - er * 0.3f, ey + oy - er * 0.3f, er * 0.35f, fill);
                    fill.setColor(DARK);
                }
            }
        }

        // брови
        if (emotion == ANGRY) {
            canvas.drawLine(cx - ex - er * 1.6f, ey - er * 2.6f, cx - ex + er * 1.5f, ey - er * 1.3f, line);
            canvas.drawLine(cx + ex + er * 1.6f, ey - er * 2.6f, cx + ex - er * 1.5f, ey - er * 1.3f, line);
        } else if (emotion == SAD) {
            canvas.drawLine(cx - ex - er * 1.5f, ey - er * 1.3f, cx - ex + er * 1.5f, ey - er * 2.6f, line);
            canvas.drawLine(cx + ex + er * 1.5f, ey - er * 1.3f, cx + ex - er * 1.5f, ey - er * 2.6f, line);
            fill.setColor(0xFF7EC8FF);
            float ty = ey + er * 1.6f + ((t * 0.9f) % 1f) * r * 0.5f;
            canvas.drawCircle(cx - ex, ty, er * 0.55f, fill);
        }

        // точки раздумий
        if (emotion == THINKING) {
            fill.setColor(0xFFFFFFFF);
            for (int i = 0; i < 3; i++) {
                float rr = r * 0.06f * (0.7f + 0.3f * (float) Math.sin(t * 6f - i * 1.2f));
                canvas.drawCircle(cx + r * 0.55f + i * r * 0.16f, cy - r * 0.68f, rr, fill);
            }
        }

        // рот
        if (talking && emotion != SLEEPY) {
            float open = 0.5f + 0.5f * (float) Math.sin(t * 14f);
            fill.setColor(DARK);
            rect.set(cx - r * 0.16f, cy + r * 0.28f, cx + r * 0.16f, cy + r * (0.34f + 0.22f * open));
            canvas.drawOval(rect, fill);
        } else if (emotion == HAPPY) {
            fill.setColor(DARK);
            path.reset();
            path.moveTo(cx - r * 0.26f, cy + r * 0.22f);
            path.quadTo(cx, cy + r * 0.66f, cx + r * 0.26f, cy + r * 0.22f);
            path.close();
            canvas.drawPath(path, fill);
        } else if (emotion == ANGRY || emotion == SAD) {
            rect.set(cx - r * 0.22f, cy + r * 0.38f, cx + r * 0.22f, cy + r * 0.62f);
            canvas.drawArc(rect, 200f, 140f, false, line);
        } else if (emotion == SURPRISED) {
            canvas.drawCircle(cx, cy + r * 0.40f, r * 0.10f, line);
        } else if (emotion == SLEEPY) {
            fill.setColor(DARK);
            canvas.drawCircle(cx, cy + r * 0.38f, r * (0.05f + 0.025f * (float) Math.sin(t * 2f)), fill);
        } else if (emotion == THINKING) {
            canvas.drawLine(cx - r * 0.12f, cy + r * 0.40f, cx + r * 0.12f, cy + r * 0.40f, line);
        } else {
            rect.set(cx - r * 0.28f, cy + r * 0.12f, cx + r * 0.28f, cy + r * 0.50f);
            canvas.drawArc(rect, 20f, 140f, false, line);
        }

        canvas.restore();
        postInvalidateOnAnimation();
    }
}
