package com.bubble.ai;

import android.service.voice.VoiceInteractionService;

/** Позволяет выбрать BubbleAI ассистентом по умолчанию (вызов долгим нажатием кнопки питания). */
public class BubbleInteractionService extends VoiceInteractionService {
}
