package com.bubble.ai;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.view.accessibility.AccessibilityNodeInfo;

import org.json.JSONObject;

import java.util.List;
import java.util.Locale;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Выполняет действия: будильники, нажатия, печать, свайпы, запуск приложений. */
final class Actions {

    private final BubbleAccessService s;

    Actions(BubbleAccessService s) {
        this.s = s;
    }

    static void sleep(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    void run(JSONObject a) {
        String type = a.optString("type", "");
        try {
            switch (type) {
                case "alarm":
                    alarm(a.optInt("hour", 7), a.optInt("minute", 0), a.optString("label", "BubbleAI"));
                    break;
                case "timer":
                    timer(a.optInt("seconds", 60), a.optString("label", "BubbleAI"));
                    break;
                case "open_app":
                    openApp(a.optString("name", ""));
                    break;
                case "tap": {
                    double x = a.optDouble("x", Double.NaN);
                    double y = a.optDouble("y", Double.NaN);
                    if (!Double.isNaN(x) && !Double.isNaN(y)) tap((float) x, (float) y, 60);
                    break;
                }
                case "tap_text":
                    tapText(a.optString("text", ""));
                    break;
                case "type":
                    typeText(a.optString("text", ""));
                    break;
                case "swipe":
                    swipe((float) a.optDouble("x1", 0), (float) a.optDouble("y1", 0),
                            (float) a.optDouble("x2", 0), (float) a.optDouble("y2", 0),
                            a.optLong("ms", 300));
                    break;
                case "back":
                    s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK);
                    break;
                case "home":
                    s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME);
                    break;
                case "recents":
                    s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS);
                    break;
                case "notifications":
                    s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS);
                    break;
                case "wait":
                    sleep(Math.min(a.optLong("ms", 500), 10000));
                    break;
                default:
                    s.appendLog("⚠ Неизвестное действие: " + type);
            }
        } catch (Exception e) {
            s.appendLog("⚠ " + type + ": " + e.getMessage());
        }
        sleep(450);
    }

    // ---------- будильники ----------

    private void alarm(int hour, int minute, String label) {
        hour = Math.max(0, Math.min(23, hour));
        minute = Math.max(0, Math.min(59, minute));
        Intent i = new Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        s.startActivity(i);
        s.appendLog(String.format(Locale.US, "⏰ Будильник на %02d:%02d", hour, minute));
    }

    private void timer(int seconds, String label) {
        seconds = Math.max(1, seconds);
        Intent i = new Intent(AlarmClock.ACTION_SET_TIMER)
                .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        s.startActivity(i);
        s.appendLog("⏱ Таймер на " + seconds + " с");
    }

    // ---------- приложения ----------

    private void openApp(String name) {
        PackageManager pm = s.getPackageManager();
        String target = null;
        if (name.contains(".") && pm.getLaunchIntentForPackage(name) != null) target = name;
        if (target == null) {
            Intent main = new Intent(Intent.ACTION_MAIN);
            main.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
            String q = name.toLowerCase(Locale.ROOT).trim();
            for (ResolveInfo ri : list) {
                String label = ri.loadLabel(pm).toString().toLowerCase(Locale.ROOT);
                if (label.equals(q)) {
                    target = ri.activityInfo.packageName;
                    break;
                }
            }
            if (target == null && q.length() > 1) {
                for (ResolveInfo ri : list) {
                    String label = ri.loadLabel(pm).toString().toLowerCase(Locale.ROOT);
                    if (label.length() > 1 && (label.contains(q) || q.contains(label))) {
                        target = ri.activityInfo.packageName;
                        break;
                    }
                }
            }
        }
        if (target == null) {
            s.appendLog("⚠ Не нашёл приложение: " + name);
            return;
        }
        Intent i = pm.getLaunchIntentForPackage(target);
        if (i != null) {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            s.startActivity(i);
        }
    }

    // ---------- жесты ----------

    boolean gesture(Path p, long dur) {
        final CountDownLatch latch = new CountDownLatch(1);
        final boolean[] ok = {false};
        GestureDescription.Builder b = new GestureDescription.Builder();
        b.addStroke(new GestureDescription.StrokeDescription(p, 0, Math.max(1, dur)));
        final GestureDescription g = b.build();
        s.main.post(new Runnable() {
            @Override
            public void run() {
                boolean accepted = s.dispatchGesture(g, new AccessibilityService.GestureResultCallback() {
                    @Override
                    public void onCompleted(GestureDescription d) {
                        ok[0] = true;
                        latch.countDown();
                    }

                    @Override
                    public void onCancelled(GestureDescription d) {
                        latch.countDown();
                    }
                }, null);
                if (!accepted) latch.countDown();
            }
        });
        try {
            latch.await(dur + 3000, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return ok[0];
    }

    boolean tap(float x, float y, long dur) {
        Path p = new Path();
        p.moveTo(x, y);
        return gesture(p, dur);
    }

    boolean swipe(float x1, float y1, float x2, float y2, long ms) {
        Path p = new Path();
        p.moveTo(x1, y1);
        p.lineTo(x2, y2);
        return gesture(p, Math.max(100, Math.min(ms, 2000)));
    }

    // ---------- по элементам экрана ----------

    private void tapText(String text) {
        AccessibilityNodeInfo root = s.targetRoot();
        if (root == null) {
            s.appendLog("⚠ Экран недоступен");
            return;
        }
        List<AccessibilityNodeInfo> found = root.findAccessibilityNodeInfosByText(text);
        if (found == null || found.isEmpty()) {
            s.appendLog("⚠ Не вижу на экране: " + text);
            return;
        }
        AccessibilityNodeInfo n = found.get(0);
        AccessibilityNodeInfo c = n;
        while (c != null && !c.isClickable()) c = c.getParent();
        if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return;
        Rect r = new Rect();
        n.getBoundsInScreen(r);
        tap(r.centerX(), r.centerY(), 60);
    }

    private void typeText(String text) {
        AccessibilityNodeInfo root = s.targetRoot();
        if (root == null) {
            s.appendLog("⚠ Экран недоступен");
            return;
        }
        AccessibilityNodeInfo f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
        if (f == null) f = firstEditable(root, 0);
        if (f == null) {
            s.appendLog("⚠ Не вижу поле ввода");
            return;
        }
        CharSequence cur = f.isShowingHintText() ? null : f.getText();
        String full = (cur == null ? "" : cur.toString()) + text;
        Bundle b = new Bundle();
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, full);
        f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b);
    }

    static AccessibilityNodeInfo firstEditable(AccessibilityNodeInfo n, int depth) {
        if (n == null || depth > 40) return null;
        if (n.isEditable()) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = firstEditable(n.getChild(i), depth + 1);
            if (r != null) return r;
        }
        return null;
    }
}
