package com.bubble.ai;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Хранит расположение кнопок BubblePRO для каждой игры (по имени пакета). */
final class ProStore {

    static class Btn {
        float x;
        float y;
        String label = "";
        int mode = 0;
    }

    static final String[] MODE_NAMES = {
            "тап", "удержание", "свайп вверх", "свайп вниз", "свайп влево", "свайп вправо"
    };
    static final String[] MODE_SYMBOLS = {"●", "◉", "↑", "↓", "←", "→"};

    private ProStore() {}

    static List<Btn> load(Context c, String pkg) {
        List<Btn> out = new ArrayList<>();
        String js = c.getSharedPreferences("bubble", Context.MODE_PRIVATE).getString("layout:" + pkg, "[]");
        try {
            JSONArray a = new JSONArray(js);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Btn b = new Btn();
                b.x = (float) o.optDouble("x", 0);
                b.y = (float) o.optDouble("y", 0);
                b.label = o.optString("label", "");
                b.mode = o.optInt("mode", 0);
                if (b.mode < 0 || b.mode >= MODE_NAMES.length) b.mode = 0;
                out.add(b);
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    static void save(Context c, String pkg, List<Btn> list) {
        JSONArray a = new JSONArray();
        try {
            for (Btn b : list) {
                JSONObject o = new JSONObject();
                o.put("x", b.x);
                o.put("y", b.y);
                o.put("label", b.label);
                o.put("mode", b.mode);
                a.put(o);
            }
        } catch (Exception ignored) {
        }
        c.getSharedPreferences("bubble", Context.MODE_PRIVATE).edit().putString("layout:" + pkg, a.toString()).apply();
    }
}
