package com.bubble.ai;

import android.content.Context;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** Редактор расположения кнопок BubblePRO: расставляешь кружки на кнопки игры и подписываешь их. */
final class ProEditor {

    private final BubbleAccessService s;
    private final WindowManager wm;
    private final int size;

    private FrameLayout root;
    private EditText labelEdit;
    private Button modeBtn;
    private final List<ProStore.Btn> list = new ArrayList<>();
    private final List<TextView> views = new ArrayList<>();
    private int selected = -1;
    private String pkg = "";
    private boolean showing = false;
    private boolean updating = false;

    ProEditor(BubbleAccessService s) {
        this.s = s;
        this.wm = (WindowManager) s.getSystemService(Context.WINDOW_SERVICE);
        this.size = s.dp(60);
    }

    boolean isShowing() {
        return showing;
    }

    void show(String gamePkg) {
        if (showing) return;
        pkg = gamePkg;
        list.clear();
        list.addAll(ProStore.load(s, pkg));
        views.clear();
        selected = -1;

        root = new FrameLayout(s);
        root.setBackgroundColor(0x66000000);

        LinearLayout bar = new LinearLayout(s);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.setPadding(s.dp(10), s.dp(36), s.dp(10), s.dp(10));
        bar.setBackgroundColor(0xEE101828);

        TextView title = new TextView(s);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(13);
        String shortName = pkg.contains(".") ? pkg.substring(pkg.lastIndexOf('.') + 1) : pkg;
        title.setText("📐 BubblePRO · игра: " + shortName
                + "\nРасставь кружки на кнопки игры. Коснись кружка и дай ему имя (например «прыжок»). ИИ знает кнопки только по имени.");
        bar.addView(title);

        LinearLayout row1 = new LinearLayout(s);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.setGravity(Gravity.CENTER_VERTICAL);
        labelEdit = new EditText(s);
        labelEdit.setHint("Имя выбранной кнопки");
        labelEdit.setTextColor(0xFFFFFFFF);
        labelEdit.setHintTextColor(0xFF8A9BB8);
        labelEdit.setSingleLine(true);
        labelEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence cs, int a, int b, int c) {}

            @Override
            public void onTextChanged(CharSequence cs, int a, int b, int c) {}

            @Override
            public void afterTextChanged(Editable e) {
                if (updating || selected < 0 || selected >= list.size()) return;
                list.get(selected).label = e.toString().trim();
                refreshAll();
            }
        });
        row1.addView(labelEdit, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        modeBtn = smallBtn("Режим: тап", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selected < 0 || selected >= list.size()) return;
                ProStore.Btn b = list.get(selected);
                b.mode = (b.mode + 1) % ProStore.MODE_NAMES.length;
                refreshAll();
                updateModeBtn();
            }
        });
        row1.addView(modeBtn);
        bar.addView(row1);

        LinearLayout row2 = new LinearLayout(s);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(smallBtn("＋ Кнопка", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addButton();
            }
        }));
        row2.addView(smallBtn("🗑 Удалить", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteSelected();
            }
        }));
        row2.addView(smallBtn("💾 Сохранить", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                save();
                close();
            }
        }));
        row2.addView(smallBtn("✕ Отмена", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                close();
            }
        }));
        bar.addView(row2);

        root.addView(bar, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP));

        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING;
        try {
            wm.addView(root, p);
            showing = true;
        } catch (Exception e) {
            s.appendLog("⚠ Не могу открыть редактор: " + e.getMessage());
            return;
        }

        root.post(new Runnable() {
            @Override
            public void run() {
                int[] loc = new int[2];
                root.getLocationOnScreen(loc);
                for (ProStore.Btn b : list) {
                    TextView tv = makeMarker();
                    tv.setX(b.x - loc[0] - size / 2f);
                    tv.setY(b.y - loc[1] - size / 2f);
                }
                refreshAll();
            }
        });
    }

    private Button smallBtn(String text, View.OnClickListener l) {
        Button b = new Button(s);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setText(text);
        b.setOnClickListener(l);
        return b;
    }

    private TextView makeMarker() {
        final TextView tv = new TextView(s);
        tv.setGravity(Gravity.CENTER);
        tv.setTextColor(0xFFFFFFFF);
        tv.setTextSize(11);
        tv.setTypeface(null, Typeface.BOLD);
        root.addView(tv, new FrameLayout.LayoutParams(size, size));
        views.add(tv);
        tv.setOnTouchListener(new View.OnTouchListener() {
            private float ox;
            private float oy;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        select(views.indexOf(tv));
                        ox = tv.getX() - e.getRawX();
                        oy = tv.getY() - e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        tv.setX(e.getRawX() + ox);
                        tv.setY(e.getRawY() + oy);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        return true;
                    default:
                        return false;
                }
            }
        });
        return tv;
    }

    private void addButton() {
        int[] loc = new int[2];
        root.getLocationOnScreen(loc);
        ProStore.Btn b = new ProStore.Btn();
        b.x = s.getResources().getDisplayMetrics().widthPixels / 2f;
        b.y = s.getResources().getDisplayMetrics().heightPixels / 2f;
        list.add(b);
        TextView tv = makeMarker();
        tv.setX(b.x - loc[0] - size / 2f);
        tv.setY(b.y - loc[1] - size / 2f);
        select(list.size() - 1);
    }

    private void deleteSelected() {
        if (selected < 0 || selected >= list.size()) return;
        root.removeView(views.get(selected));
        views.remove(selected);
        list.remove(selected);
        selected = -1;
        updating = true;
        labelEdit.setText("");
        updating = false;
        refreshAll();
        updateModeBtn();
    }

    private void select(int i) {
        if (i < 0 || i >= list.size()) return;
        selected = i;
        updating = true;
        labelEdit.setText(list.get(i).label);
        labelEdit.setSelection(labelEdit.getText().length());
        updating = false;
        refreshAll();
        updateModeBtn();
    }

    private void updateModeBtn() {
        if (selected >= 0 && selected < list.size()) {
            modeBtn.setText("Режим: " + ProStore.MODE_NAMES[list.get(selected).mode]);
        } else {
            modeBtn.setText("Режим: тап");
        }
    }

    private void refreshAll() {
        for (int i = 0; i < views.size() && i < list.size(); i++) {
            ProStore.Btn b = list.get(i);
            TextView tv = views.get(i);
            tv.setText((i + 1) + " " + ProStore.MODE_SYMBOLS[b.mode] + (b.label.isEmpty() ? "" : "\n" + b.label));
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(i == selected ? 0xEEFF9F1A : 0xCC3FA0FF);
            g.setStroke(s.dp(2), 0xFFFFFFFF);
            tv.setBackground(g);
        }
    }

    private void syncPositions() {
        int[] loc = new int[2];
        root.getLocationOnScreen(loc);
        for (int i = 0; i < views.size() && i < list.size(); i++) {
            TextView tv = views.get(i);
            ProStore.Btn b = list.get(i);
            b.x = tv.getX() + size / 2f + loc[0];
            b.y = tv.getY() + size / 2f + loc[1];
        }
    }

    private void save() {
        syncPositions();
        ProStore.save(s, pkg, list);
        s.appendLog("💾 Кнопок сохранено: " + list.size());
    }

    void close() {
        if (!showing) return;
        try {
            wm.removeView(root);
        } catch (Exception ignored) {
        }
        showing = false;
        s.onEditorClosed();
    }
}
