package com.bubble.ai;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final String[] TRIGGERS = {
            "Выключено",
            "Обе кнопки громкости вместе",
            "Двойное нажатие «громкость −»",
            "Удержание «громкость −» (0,7 с)"
    };

    private TextView status;
    private Button triggerBtn;
    private SharedPreferences prefs;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("bubble", MODE_PRIVATE);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFFF4F9FF);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(18), dp(36), dp(18), dp(24));
        sv.addView(l);

        BubbleView mascot = new BubbleView(this);
        l.addView(mascot, new LinearLayout.LayoutParams(dp(140), dp(140)));

        TextView title = new TextView(this);
        title.setText("BubbleAI 🫧");
        title.setTextSize(26);
        title.setTextColor(0xFF1B2A41);
        l.addView(title);

        status = new TextView(this);
        status.setTextSize(14);
        status.setTextColor(0xFF1B2A41);
        status.setPadding(0, dp(8), 0, dp(12));
        l.addView(status);

        addBtn(l, "1. Включить службу доступности", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        addBtn(l, "Пункт серый? (Android 13+) → Разрешить ограниченные настройки", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
                Toast.makeText(MainActivity.this,
                        "Нажми ⋮ вверху справа → «Разрешить ограниченные настройки»", Toast.LENGTH_LONG).show();
            }
        });
        addBtn(l, "2. Разрешить показ поверх окон", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
            }
        });
        addBtn(l, "3. Разрешить микрофон (для BubbleLive)", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
            }
        });
        addBtn(l, "4. Сделать ассистентом (кнопка питания)", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent(Settings.ACTION_VOICE_INPUT_SETTINGS));
                } catch (Exception e) {
                    try {
                        startActivity(new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS));
                    } catch (Exception e2) {
                        Toast.makeText(MainActivity.this,
                                "Открой Настройки → Приложения → Приложения по умолчанию → Помощник",
                                Toast.LENGTH_LONG).show();
                    }
                }
            }
        });

        triggerBtn = addBtn(l, "", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Кнопка вызова пузыря")
                        .setItems(TRIGGERS, new android.content.DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(android.content.DialogInterface d, int which) {
                                prefs.edit().putInt("trigger", which).apply();
                                refresh();
                            }
                        })
                        .show();
            }
        });

        CheckBox always = new CheckBox(this);
        always.setText("Пузырь всегда на экране");
        always.setTextColor(0xFF1B2A41);
        always.setChecked(prefs.getBoolean("always", false));
        always.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                prefs.edit().putBoolean("always", checked).apply();
                BubbleAccessService s = BubbleAccessService.instance;
                if (s != null) {
                    if (checked) s.showBubble();
                    else s.hideBubble();
                }
            }
        });
        l.addView(always);

        addBtn(l, "🫧 Показать пузырь", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BubbleAccessService s = BubbleAccessService.instance;
                if (s == null) {
                    Toast.makeText(MainActivity.this, "Сначала включи службу доступности (шаг 1)", Toast.LENGTH_LONG).show();
                } else {
                    s.showPanel();
                }
            }
        });

        TextView help = new TextView(this);
        help.setTextSize(13);
        help.setTextColor(0xFF3A4B66);
        help.setPadding(0, dp(16), 0, 0);
        help.setText("Как пользоваться\n\n"
                + "• Нужно установленное приложение DeepSeek с входом в аккаунт. BubbleAI сам открывает его, печатает вопрос и читает ответ; на это время экран накрывается пузырём, а в недавних приложениях DeepSeek не появляется.\n"
                + "• Вызови пузыря выбранной кнопкой (или долгим нажатием питания, если назначен ассистентом) и пиши команды: «поставь будильник на 7:30», «открой YouTube», «напиши привет».\n"
                + "• BubblePRO: открой игру, вызови пузыря → «📐 Кнопки», расставь кружки на кнопки игры и дай им имена. Потом напиши цель и нажми «▶ Играть». Чтобы просто повторять нажатия без ИИ, напиши «макрос: кнопка1, кнопка2». Остановка: нажми на пузырь.\n"
                + "• BubbleLive: кнопка «🎙 Live» в окне пузыря. Говоришь, он отвечает голосом.\n"
                + "• ИИ видит экран игры только как текст, поэтому подходят медленные игры: кликеры, пошаговые, головоломки.");
        l.addView(help);

        setContentView(sv);
    }

    private Button addBtn(LinearLayout parent, String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(text);
        b.setOnClickListener(l);
        parent.addView(b);
        return b;
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        refresh();
    }

    private void refresh() {
        boolean acc = BubbleAccessService.instance != null;
        boolean overlay = Settings.canDrawOverlays(this);
        boolean mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
        boolean ds = getPackageManager().getLaunchIntentForPackage(DeepSeekBridge.PKG) != null;
        status.setText("Служба доступности: " + (acc ? "✅" : "❌")
                + "\nПоверх окон: " + (overlay ? "✅" : "❌")
                + "\nМикрофон: " + (mic ? "✅" : "❌")
                + "\nDeepSeek установлен: " + (ds ? "✅" : "❌"));
        int t = prefs.getInt("trigger", 1);
        if (t < 0 || t >= TRIGGERS.length) t = 1;
        triggerBtn.setText("Кнопка вызова: " + TRIGGERS[t]);
    }
}
