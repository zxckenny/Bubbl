package com.bubble.ai;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Мост к установленному приложению DeepSeek: открывает его (без записи во вкладке недавних),
 * печатает вопрос, ждёт ответ и возвращает тебя обратно в прошлое приложение.
 */
final class DeepSeekBridge {

    static final String PKG = "com.deepseek.chat";

    private final BubbleAccessService s;
    volatile boolean abort = false;
    volatile String lastError = "";

    DeepSeekBridge(BubbleAccessService s) {
        this.s = s;
    }

    boolean installed() {
        return s.getPackageManager().getLaunchIntentForPackage(PKG) != null;
    }

    /** Блокирующий вызов, запускать из рабочего потока. Возвращает текст ответа или null. */
    String ask(String prompt, String returnPkg) {
        lastError = "";
        Intent i = s.getPackageManager().getLaunchIntentForPackage(PKG);
        if (i == null) {
            lastError = "DeepSeek не установлен";
            return null;
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS
                | Intent.FLAG_ACTIVITY_NO_ANIMATION
                | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        try {
            s.startActivity(i);
        } catch (Exception e) {
            lastError = "не могу открыть DeepSeek: " + e.getMessage();
            return null;
        }

        String result = null;
        try {
            result = doAsk(prompt);
        } finally {
            goBack(returnPkg);
        }
        return result;
    }

    private String doAsk(String prompt) {
        AccessibilityNodeInfo input = waitInput(20000);
        if (input == null) {
            lastError = abort ? "остановлено" : "не вижу поле ввода DeepSeek (войди в аккаунт и закрой подсказки)";
            return null;
        }
        List<String> baseline = collectTexts(deepRoot());

        input.performAction(AccessibilityNodeInfo.ACTION_FOCUS);
        input.performAction(AccessibilityNodeInfo.ACTION_CLICK);
        Actions.sleep(250);
        Bundle b = new Bundle();
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, prompt);
        if (!input.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)) {
            lastError = "не удалось ввести текст в DeepSeek";
            return null;
        }
        Actions.sleep(500);

        AccessibilityNodeInfo root = deepRoot();
        AccessibilityNodeInfo input2 = root == null ? null : lastEditable(root, 0);
        if (input2 == null) input2 = input;
        sendClick(root, input2);
        Actions.sleep(1200);

        // если текст остался в поле — пробуем Enter и тап по правому краю
        AccessibilityNodeInfo again = lastEditable(deepRoot(), 0);
        if (again != null && stillFull(again, prompt)) {
            if (Build.VERSION.SDK_INT >= 30) {
                again.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.getId());
                Actions.sleep(800);
            }
            again = lastEditable(deepRoot(), 0);
            if (again != null && stillFull(again, prompt)) {
                Rect r = new Rect();
                again.getBoundsInScreen(r);
                float x = s.getResources().getDisplayMetrics().widthPixels - s.dp(30);
                s.actions.tap(x, r.centerY(), 60);
                Actions.sleep(800);
            }
        }

        String head = prompt.length() > 30 ? prompt.substring(0, 30) : prompt;
        String prev = "";
        int stable = 0;
        String candidate = "";
        long end = System.currentTimeMillis() + 90000;
        while (System.currentTimeMillis() < end && !abort) {
            Actions.sleep(1000);
            AccessibilityNodeInfo r = deepRoot();
            if (r == null) continue;
            candidate = extractAnswer(collectTexts(r), baseline, head, prompt);
            if (!candidate.isEmpty() && candidate.equals(prev)) stable++;
            else stable = 0;
            prev = candidate;
            int a = candidate.indexOf('{');
            int c = candidate.lastIndexOf('}');
            if (stable >= 2 && a >= 0 && c > a) return candidate;
        }
        if (abort) {
            lastError = "остановлено";
            return null;
        }
        if (!candidate.isEmpty()) return candidate;
        lastError = "DeepSeek не ответил вовремя";
        return null;
    }

    private boolean stillFull(AccessibilityNodeInfo n, String prompt) {
        if (n.isShowingHintText()) return false;
        CharSequence t = n.getText();
        return t != null && t.length() > prompt.length() / 2;
    }

    private void goBack(String returnPkg) {
        Intent back = null;
        if (returnPkg != null) back = s.getPackageManager().getLaunchIntentForPackage(returnPkg);
        if (back != null) {
            back.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_NO_ANIMATION);
            try {
                s.startActivity(back);
            } catch (Exception e) {
                s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME);
            }
        } else {
            s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME);
        }
        Actions.sleep(900);
    }

    // ---------- работа с деревом экрана ----------

    private static boolean isPkg(AccessibilityNodeInfo n, String pkg) {
        return n != null && n.getPackageName() != null && pkg.contentEquals(n.getPackageName());
    }

    AccessibilityNodeInfo deepRoot() {
        AccessibilityNodeInfo r = s.getRootInActiveWindow();
        if (isPkg(r, PKG)) return r;
        List<AccessibilityWindowInfo> ws = s.getWindows();
        if (ws != null) {
            for (AccessibilityWindowInfo w : ws) {
                AccessibilityNodeInfo wr = w.getRoot();
                if (isPkg(wr, PKG)) return wr;
            }
        }
        return null;
    }

    private AccessibilityNodeInfo waitInput(long timeoutMs) {
        long end = System.currentTimeMillis() + timeoutMs;
        while (System.currentTimeMillis() < end && !abort) {
            AccessibilityNodeInfo r = deepRoot();
            if (r != null) {
                AccessibilityNodeInfo e = lastEditable(r, 0);
                if (e != null) {
                    Actions.sleep(600);
                    return e;
                }
            }
            Actions.sleep(500);
        }
        return null;
    }

    /** Самое нижнее редактируемое поле. */
    private static AccessibilityNodeInfo lastEditable(AccessibilityNodeInfo root, int depth) {
        if (root == null) return null;
        List<AccessibilityNodeInfo> all = new ArrayList<>();
        flatten(root, all, 0);
        AccessibilityNodeInfo best = null;
        int bestTop = -1;
        Rect r = new Rect();
        for (AccessibilityNodeInfo n : all) {
            if (n.isEditable()) {
                n.getBoundsInScreen(r);
                if (r.top >= bestTop) {
                    bestTop = r.top;
                    best = n;
                }
            }
        }
        return best;
    }

    private static void flatten(AccessibilityNodeInfo n, List<AccessibilityNodeInfo> out, int depth) {
        if (n == null || depth > 45 || out.size() > 3000) return;
        out.add(n);
        for (int i = 0; i < n.getChildCount(); i++) flatten(n.getChild(i), out, depth + 1);
    }

    private void sendClick(AccessibilityNodeInfo root, AccessibilityNodeInfo input) {
        if (root == null || input == null) return;
        Rect ir = new Rect();
        input.getBoundsInScreen(ir);
        List<AccessibilityNodeInfo> all = new ArrayList<>();
        flatten(root, all, 0);

        AccessibilityNodeInfo send = null;
        for (AccessibilityNodeInfo n : all) {
            CharSequence d = n.getContentDescription();
            CharSequence t = n.getText();
            String str = ((d == null ? "" : d) + " " + (t == null ? "" : t)).toLowerCase(Locale.ROOT);
            if (n.isEnabled() && (str.contains("send") || str.contains("отправ") || str.contains("发送"))) {
                send = n;
                break;
            }
        }
        if (send == null) {
            int bestX = -1;
            Rect r = new Rect();
            int pad = s.dp(20);
            for (AccessibilityNodeInfo n : all) {
                if (!n.isEnabled() || !n.isClickable() || n.isEditable()) continue;
                n.getBoundsInScreen(r);
                int cy = r.centerY();
                if (cy >= ir.top - pad && cy <= ir.bottom + pad && r.centerX() > ir.centerX() && r.centerX() > bestX) {
                    bestX = r.centerX();
                    send = n;
                }
            }
        }
        if (send != null) {
            AccessibilityNodeInfo c = send;
            while (c != null && !c.isClickable()) c = c.getParent();
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return;
            Rect r = new Rect();
            send.getBoundsInScreen(r);
            s.actions.tap(r.centerX(), r.centerY(), 60);
        } else {
            float x = s.getResources().getDisplayMetrics().widthPixels - s.dp(30);
            s.actions.tap(x, ir.centerY(), 60);
        }
    }

    List<String> collectTexts(AccessibilityNodeInfo root) {
        List<String> out = new ArrayList<>();
        if (root == null) return out;
        List<AccessibilityNodeInfo> all = new ArrayList<>();
        flatten(root, all, 0);
        for (AccessibilityNodeInfo n : all) {
            if (n.isEditable()) continue;
            CharSequence t = n.getText();
            if (t != null && t.toString().trim().length() > 0) out.add(t.toString().trim());
        }
        return out;
    }

    /** Текст экрана для режима игры (обрезанный). */
    String screenText(AccessibilityNodeInfo root, int max) {
        StringBuilder sb = new StringBuilder();
        for (String t : collectTexts(root)) {
            if (sb.length() + t.length() + 2 > max) break;
            if (sb.length() > 0) sb.append(" | ");
            sb.append(t);
        }
        return sb.toString();
    }

    private String extractAnswer(List<String> texts, List<String> baseline, String head, String prompt) {
        int last = -1;
        for (int i = 0; i < texts.size(); i++) {
            if (texts.get(i).contains(head)) last = i;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = last + 1; i < texts.size(); i++) {
            String t = texts.get(i);
            if (last < 0 && (baseline.contains(t) || prompt.contains(t))) continue;
            if (last >= 0 && baseline.contains(t)) continue;
            if (sb.length() > 0) sb.append("\n");
            sb.append(t);
        }
        return sb.toString();
    }
}
