package com.bubble.ai;

import android.content.Context;
import android.util.DisplayMetrics;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Составляет запросы к DeepSeek и разбирает его JSON-ответы. */
final class Brain {

    static class Reply {
        String emotion = "neutral";
        String say = "";
        JSONArray actions = null;
        List<String> press = new ArrayList<>();
        long waitMs = 1500;
        boolean done = false;
    }

    private Brain() {}

    static final String SYSTEM =
            "Ты BubbleAI - милый пузырь-помощник, который управляет телефоном Android. "
            + "Отвечай СТРОГО одним JSON-объектом, без markdown, без блоков кода и без пояснений. "
            + "Формат: {\"emotion\":\"happy|angry|sad|surprised|love|sleepy|neutral\",\"say\":\"короткий ответ пользователю\",\"actions\":[...]}. "
            + "Действия: "
            + "{\"type\":\"alarm\",\"hour\":7,\"minute\":30,\"label\":\"текст\"}; "
            + "{\"type\":\"timer\",\"seconds\":300}; "
            + "{\"type\":\"open_app\",\"name\":\"название приложения\"}; "
            + "{\"type\":\"tap\",\"x\":500,\"y\":900}; "
            + "{\"type\":\"tap_text\",\"text\":\"надпись на кнопке\"}; "
            + "{\"type\":\"type\",\"text\":\"текст для активного поля ввода\"}; "
            + "{\"type\":\"swipe\",\"x1\":500,\"y1\":1500,\"x2\":500,\"y2\":500,\"ms\":300}; "
            + "{\"type\":\"back\"}; {\"type\":\"home\"}; {\"type\":\"recents\"}; {\"type\":\"notifications\"}; "
            + "{\"type\":\"wait\",\"ms\":1000}. "
            + "Если действия не нужны, верни пустой массив actions. Если просят просто поговорить, ответь в say. "
            + "Поле say пиши коротко, на языке пользователя.";

    static final String SYSTEM_PRO =
            "Ты BubbleAI в режиме BubblePRO: ты играешь в игру за пользователя, нажимая заранее размеченные кнопки. "
            + "Отвечай СТРОГО одним JSON-объектом, без markdown и без блоков кода. "
            + "Формат: {\"emotion\":\"happy|angry|sad|surprised|love|sleepy|neutral\",\"say\":\"что думаешь, коротко\","
            + "\"press\":[\"имя кнопки\"],\"wait_ms\":1500,\"done\":false}. "
            + "Используй ТОЛЬКО имена кнопок из списка. В press можно до 5 нажатий подряд. "
            + "done поставь true, когда цель выполнена.";

    static String userPrompt(Context c, String text, String pkg) {
        DisplayMetrics m = c.getResources().getDisplayMetrics();
        return SYSTEM + "\n\nЭкран телефона: " + m.widthPixels + "x" + m.heightPixels
                + " пикселей. Сейчас открыто приложение: " + (pkg == null ? "неизвестно" : pkg)
                + ".\nЗапрос пользователя: " + text;
    }

    static String proPrompt(String goal, String pkg, List<ProStore.Btn> btns, String screen, String hist) {
        StringBuilder sb = new StringBuilder();
        sb.append(SYSTEM_PRO).append("\n\nЦель: ").append(goal);
        sb.append("\nИгра (пакет): ").append(pkg);
        sb.append("\nКнопки: ");
        for (int i = 0; i < btns.size(); i++) {
            ProStore.Btn b = btns.get(i);
            String name = b.label.isEmpty() ? String.valueOf(i + 1) : b.label;
            if (i > 0) sb.append(", ");
            sb.append(name).append(" (").append(ProStore.MODE_NAMES[b.mode]).append(")");
        }
        sb.append("\nТекст на экране сейчас: ").append(screen.isEmpty() ? "(текста не видно)" : screen);
        sb.append("\nПоследние нажатия: ").append(hist.isEmpty() ? "(пока нет)" : hist);
        return sb.toString();
    }

    static Reply parse(String raw) {
        Reply r = new Reply();
        if (raw == null) raw = "";
        try {
            int a = raw.indexOf('{');
            int b = raw.lastIndexOf('}');
            if (a >= 0 && b > a) {
                JSONObject o = new JSONObject(raw.substring(a, b + 1));
                r.emotion = o.optString("emotion", "neutral");
                r.say = o.optString("say", "");
                r.actions = o.optJSONArray("actions");
                r.waitMs = o.optLong("wait_ms", 1500);
                r.done = o.optBoolean("done", false);
                JSONArray p = o.optJSONArray("press");
                if (p != null) {
                    for (int i = 0; i < p.length(); i++) r.press.add(p.optString(i));
                }
                return r;
            }
        } catch (Exception ignored) {
        }
        r.say = raw.length() > 300 ? raw.substring(0, 300) : raw;
        return r;
    }
}
