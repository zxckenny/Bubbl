package com.bubble.ai;

import android.accessibilityservice.AccessibilityService;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Главная служба BubbleAI: пузырь, окно чата, вызов по кнопкам, BubbleLive и BubblePRO. */
public class BubbleAccessService extends AccessibilityService {

    static BubbleAccessService instance;

    private static final int F_NOT_FOCUSABLE = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
    private static final int F_NOT_TOUCHABLE = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
    private static final int F_NOT_TOUCH_MODAL = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
    private static final int F_NO_LIMITS = WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;
    private static final int F_IN_SCREEN = WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;

    final Handler main = new Handler(Looper.getMainLooper());
    final ExecutorService worker = Executors.newSingleThreadExecutor();
    Actions actions;
    DeepSeekBridge bridge;
    private ProEditor editor;
    private WindowManager wm;
    private SharedPreferences prefs;

    // пузырь
    private BubbleView bubble;
    private WindowManager.LayoutParams bubbleLp;
    private boolean bubbleAdded = false;

    // окно чата
    private LinearLayout panel;
    private WindowManager.LayoutParams panelLp;
    private boolean panelOpen = false;
    private TextView logView;
    private ScrollView logScroll;
    private EditText input;

    // накрытие экрана, пока работает DeepSeek
    private LinearLayout cover;
    private BubbleView coverBubble;
    private TextView coverText;
    private WindowManager.LayoutParams coverLp;
    private boolean coverAdded = false;

    // подпись для BubbleLive
    private TextView caption;
    private WindowManager.LayoutParams captionLp;
    private boolean captionAdded = false;

    private volatile boolean busy = false;
    private volatile boolean proRunning = false;
    private volatile boolean liveOn = false;
    private volatile String gamePkg = null;

    private TextToSpeech tts;
    private boolean ttsReady = false;
    private SpeechRecognizer recognizer;

    // состояние кнопок вызова
    private boolean upHeld = false;
    private boolean downHeld = false;
    private boolean comboFired = false;
    private long lastVolDown = 0;
    private boolean holdFired = false;

    private final Runnable coverSafety = new Runnable() {
        @Override
        public void run() {
            hideCover();
        }
    };

    private final Runnable idleReset = new Runnable() {
        @Override
        public void run() {
            if (!busy && !proRunning) {
                setEmotion(BubbleView.NEUTRAL);
                if (!panelOpen && !liveOn && !prefs.getBoolean("always", false)) hideBubble();
            }
        }
    };

    private final Runnable holdRunnable = new Runnable() {
        @Override
        public void run() {
            holdFired = true;
            onAssistTrigger();
        }
    };

    int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    // ================= жизненный цикл =================

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        prefs = getSharedPreferences("bubble", MODE_PRIVATE);
        actions = new Actions(this);
        bridge = new DeepSeekBridge(this);
        editor = new ProEditor(this);
        buildBubble();
        buildPanel();
        buildCover();
        buildCaption();

        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    tts.setLanguage(new Locale("ru", "RU"));
                    tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                        @Override
                        public void onStart(String id) {
                            main.post(new Runnable() {
                                @Override
                                public void run() {
                                    bubble.setTalking(true);
                                }
                            });
                        }

                        @Override
                        public void onDone(String id) {
                            speechFinished();
                        }

                        @Override
                        public void onError(String id) {
                            speechFinished();
                        }
                    });
                    ttsReady = true;
                }
            }
        });

        if (prefs.getBoolean("always", false)) showBubble();
    }

    private void speechFinished() {
        main.post(new Runnable() {
            @Override
            public void run() {
                bubble.setTalking(false);
            }
        });
        if (liveOn) startListening();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent e) {
        if (e.getEventType() == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && e.getPackageName() != null) {
            String p = e.getPackageName().toString();
            if (!p.equals(getPackageName())
                    && !p.equals(DeepSeekBridge.PKG)
                    && !p.startsWith("com.android.systemui")
                    && !p.contains("inputmethod")
                    && !p.contains("keyboard")) {
                gamePkg = p;
            }
        }
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public boolean onUnbind(Intent intent) {
        instance = null;
        proRunning = false;
        liveOn = false;
        if (bridge != null) bridge.abort = true;
        try {
            if (editor != null) editor.close();
            if (bubbleAdded) wm.removeView(bubble);
            if (panelOpen) wm.removeView(panel);
            if (coverAdded) wm.removeView(cover);
            if (captionAdded) wm.removeView(caption);
        } catch (Exception ignored) {
        }
        bubbleAdded = false;
        panelOpen = false;
        coverAdded = false;
        captionAdded = false;
        worker.shutdownNow();
        if (tts != null) tts.shutdown();
        if (recognizer != null) {
            recognizer.destroy();
            recognizer = null;
        }
        return super.onUnbind(intent);
    }

    // ================= построение окон =================

    private WindowManager.LayoutParams lp(int w, int h, int flags) {
        return new WindowManager.LayoutParams(w, h, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                flags, PixelFormat.TRANSLUCENT);
    }

    private void buildBubble() {
        bubble = new BubbleView(this);
        int size = dp(76);
        bubbleLp = lp(size, size, F_NOT_FOCUSABLE | F_NOT_TOUCH_MODAL | F_NO_LIMITS);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        bubbleLp.x = dp(8);
        bubbleLp.y = dp(220);
        bubble.setOnTouchListener(new View.OnTouchListener() {
            private float sx;
            private float sy;
            private float dx;
            private float dy;
            private boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX();
                        sy = e.getRawY();
                        dx = bubbleLp.x - sx;
                        dy = bubbleLp.y - sy;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs(e.getRawX() - sx) > dp(6) || Math.abs(e.getRawY() - sy) > dp(6)) moved = true;
                        if (moved && bubbleAdded) {
                            bubbleLp.x = (int) (e.getRawX() + dx);
                            bubbleLp.y = (int) (e.getRawY() + dy);
                            try {
                                wm.updateViewLayout(bubble, bubbleLp);
                            } catch (Exception ignored) {
                            }
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) onBubbleTap();
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private Button btn(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setText(text);
        b.setOnClickListener(l);
        return b;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private void buildPanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(12), dp(12), dp(12));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF2F4F9FF);
        bg.setCornerRadius(dp(22));
        panel.setBackground(bg);

        logScroll = new ScrollView(this);
        logView = new TextView(this);
        logView.setTextColor(0xFF1B2A41);
        logView.setTextSize(14);
        logView.setText("🫧 Привет! Напиши команду, например: «поставь будильник на 7:30».\n");
        logScroll.addView(logView);
        panel.addView(logScroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(150)));

        LinearLayout r1 = row();
        input = new EditText(this);
        input.setHint("Команда или цель для игры…");
        input.setTextColor(0xFF1B2A41);
        input.setHintTextColor(0xFF7A8AA3);
        r1.addView(input, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        r1.addView(btn("➤", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitInput();
            }
        }));
        panel.addView(r1);

        LinearLayout r2 = row();
        r2.addView(btn("🎙 Live", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleLive();
            }
        }));
        r2.addView(btn("📐 Кнопки", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openEditor();
            }
        }));
        r2.addView(btn("▶ Играть", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String goal = input.getText().toString().trim();
                input.setText("");
                startPro(goal);
            }
        }));
        panel.addView(r2);

        LinearLayout r3 = row();
        r3.addView(btn("⏹ Стоп", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopAll();
            }
        }));
        r3.addView(btn("✕ Закрыть", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hidePanel(false);
            }
        }));
        panel.addView(r3);

        int w = getResources().getDisplayMetrics().widthPixels - dp(24);
        panelLp = lp(w, WindowManager.LayoutParams.WRAP_CONTENT, F_NOT_TOUCH_MODAL);
        panelLp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
        panelLp.y = dp(12);
        panelLp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE;
    }

    private void buildCover() {
        cover = new LinearLayout(this);
        cover.setOrientation(LinearLayout.VERTICAL);
        cover.setGravity(Gravity.CENTER);
        cover.setBackgroundColor(0xF2101828);
        coverBubble = new BubbleView(this);
        cover.addView(coverBubble, new LinearLayout.LayoutParams(dp(160), dp(160)));
        coverText = new TextView(this);
        coverText.setTextColor(0xFFFFFFFF);
        coverText.setTextSize(18);
        coverText.setGravity(Gravity.CENTER);
        cover.addView(coverText);
        coverLp = lp(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                F_NOT_FOCUSABLE | F_NOT_TOUCHABLE | F_IN_SCREEN | F_NO_LIMITS);
    }

    private void buildCaption() {
        caption = new TextView(this);
        caption.setTextColor(0xFFFFFFFF);
        caption.setTextSize(15);
        caption.setPadding(dp(14), dp(8), dp(14), dp(8));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xCC101828);
        bg.setCornerRadius(dp(16));
        caption.setBackground(bg);
        captionLp = lp(getResources().getDisplayMetrics().widthPixels - dp(40),
                WindowManager.LayoutParams.WRAP_CONTENT, F_NOT_FOCUSABLE | F_NOT_TOUCHABLE | F_NOT_TOUCH_MODAL);
        captionLp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        captionLp.y = dp(60);
    }

    // ================= показ / скрытие =================

    void showBubble() {
        main.post(new Runnable() {
            @Override
            public void run() {
                if (!bubbleAdded) {
                    try {
                        wm.addView(bubble, bubbleLp);
                        bubbleAdded = true;
                    } catch (Exception ignored) {
                    }
                }
            }
        });
    }

    void hideBubble() {
        main.post(new Runnable() {
            @Override
            public void run() {
                if (bubbleAdded) {
                    try {
                        wm.removeView(bubble);
                    } catch (Exception ignored) {
                    }
                    bubbleAdded = false;
                }
            }
        });
    }

    void showPanel() {
        main.post(new Runnable() {
            @Override
            public void run() {
                if (!bubbleAdded) {
                    try {
                        wm.addView(bubble, bubbleLp);
                        bubbleAdded = true;
                    } catch (Exception ignored) {
                    }
                }
                if (!panelOpen) {
                    try {
                        wm.addView(panel, panelLp);
                        panelOpen = true;
                    } catch (Exception ignored) {
                    }
                }
                setEmotion(BubbleView.HAPPY);
            }
        });
    }

    void hidePanel(final boolean keepBubble) {
        main.post(new Runnable() {
            @Override
            public void run() {
                if (panelOpen) {
                    try {
                        wm.removeView(panel);
                    } catch (Exception ignored) {
                    }
                    panelOpen = false;
                }
                if (!keepBubble && !prefs.getBoolean("always", false) && !proRunning && !liveOn) hideBubble();
            }
        });
    }

    void onAssistTrigger() {
        main.post(new Runnable() {
            @Override
            public void run() {
                if (panelOpen) hidePanel(false);
                else showPanel();
            }
        });
    }

    private void onBubbleTap() {
        if (proRunning) stopPro();
        else if (panelOpen) hidePanel(false);
        else showPanel();
    }

    void onEditorClosed() {
        if (instance == null) return;
        showPanel();
    }

    private void showCover(final String text) {
        main.post(new Runnable() {
            @Override
            public void run() {
                coverText.setText(text);
                if (!coverAdded) {
                    try {
                        wm.addView(cover, coverLp);
                        coverAdded = true;
                    } catch (Exception ignored) {
                    }
                }
                main.removeCallbacks(coverSafety);
                main.postDelayed(coverSafety, 150000);
            }
        });
    }

    private void hideCover() {
        main.post(new Runnable() {
            @Override
            public void run() {
                main.removeCallbacks(coverSafety);
                if (coverAdded) {
                    try {
                        wm.removeView(cover);
                    } catch (Exception ignored) {
                    }
                    coverAdded = false;
                }
            }
        });
    }

    private void showCaption(final String t) {
        main.post(new Runnable() {
            @Override
            public void run() {
                if (!liveOn) return;
                caption.setText(t);
                if (!captionAdded) {
                    try {
                        wm.addView(caption, captionLp);
                        captionAdded = true;
                    } catch (Exception ignored) {
                    }
                }
            }
        });
    }

    private void hideCaption() {
        main.post(new Runnable() {
            @Override
            public void run() {
                if (captionAdded) {
                    try {
                        wm.removeView(caption);
                    } catch (Exception ignored) {
                    }
                    captionAdded = false;
                }
            }
        });
    }

    // ================= вспомогательное =================

    void appendLog(final String line) {
        main.post(new Runnable() {
            @Override
            public void run() {
                if (logView != null) {
                    logView.append(line + "\n");
                    logScroll.post(new Runnable() {
                        @Override
                        public void run() {
                            logScroll.fullScroll(View.FOCUS_DOWN);
                        }
                    });
                }
            }
        });
    }

    private void setEmotion(final int e) {
        main.post(new Runnable() {
            @Override
            public void run() {
                bubble.setEmotion(e);
                coverBubble.setEmotion(e);
            }
        });
    }

    /** Корень окна того приложения, с которым работаем (не нашего оверлея). */
    AccessibilityNodeInfo targetRoot() {
        AccessibilityNodeInfo r = getRootInActiveWindow();
        if (r != null && r.getPackageName() != null && !getPackageName().contentEquals(r.getPackageName())) {
            return r;
        }
        List<AccessibilityWindowInfo> ws = getWindows();
        if (ws != null) {
            for (AccessibilityWindowInfo w : ws) {
                if (w.getType() != AccessibilityWindowInfo.TYPE_APPLICATION) continue;
                AccessibilityNodeInfo wr = w.getRoot();
                if (wr != null && wr.getPackageName() != null && !getPackageName().contentEquals(wr.getPackageName())) {
                    return wr;
                }
            }
        }
        return null;
    }

    /** Показывает ответ пузыря. Возвращает true, если начал озвучку. */
    private boolean say(String text, int emo, boolean speak) {
        final String t = (text == null || text.trim().isEmpty()) ? "…" : text.trim();
        setEmotion(emo);
        appendLog("🫧 " + t);
        showCaption("🫧 " + t);
        main.post(new Runnable() {
            @Override
            public void run() {
                main.removeCallbacks(idleReset);
                main.postDelayed(idleReset, 9000);
            }
        });
        if (speak && ttsReady) {
            tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, "bubble");
            return true;
        }
        return false;
    }

    private String askWithCover(String prompt, String label) {
        showCover(label);
        try {
            return bridge.ask(prompt, gamePkg);
        } finally {
            hideCover();
        }
    }

    // ================= чат =================

    private void submitInput() {
        String t = input.getText().toString().trim();
        input.setText("");
        if (!t.isEmpty()) handleUserText(t, false);
    }

    void handleUserText(final String text, final boolean voice) {
        if (busy) {
            appendLog("⏳ Я ещё занят…");
            if (voice && liveOn) startListening();
            return;
        }
        if (!bridge.installed()) {
            say("DeepSeek не установлен, а без него я не работаю.", BubbleView.SAD, false);
            return;
        }
        busy = true;
        bridge.abort = false;
        appendLog("Ты: " + text);
        setEmotion(BubbleView.THINKING);
        final boolean reopen = panelOpen;
        hidePanel(true);
        final String pkgNow = gamePkg;
        worker.submit(new Runnable() {
            @Override
            public void run() {
                boolean spoke = false;
                try {
                    String raw = askWithCover(Brain.userPrompt(BubbleAccessService.this, text, pkgNow), "Думаю…");
                    if (raw == null) {
                        spoke = say("Не вышло связаться с DeepSeek: " + bridge.lastError, BubbleView.SAD, voice);
                    } else {
                        Brain.Reply r = Brain.parse(raw);
                        spoke = say(r.say, BubbleView.emotionFromName(r.emotion), voice);
                        if (r.actions != null) {
                            Actions.sleep(500);
                            runActions(r.actions);
                        }
                    }
                } catch (Throwable t) {
                    spoke = say("Ошибка: " + t, BubbleView.SAD, false);
                } finally {
                    busy = false;
                    if (reopen && !liveOn) showPanel();
                    if (voice && liveOn && !spoke) startListening();
                }
            }
        });
    }

    private void runActions(JSONArray arr) {
        int n = Math.min(arr.length(), 12);
        for (int i = 0; i < n; i++) {
            JSONObject a = arr.optJSONObject(i);
            if (a != null) actions.run(a);
        }
    }

    // ================= кнопки вызова =================

    @Override
    protected boolean onKeyEvent(KeyEvent e) {
        int trig = prefs == null ? 0 : prefs.getInt("trigger", 1);
        if (trig == 0) return false;
        int code = e.getKeyCode();
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false;
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;

        if (trig == 1) {
            if (code == KeyEvent.KEYCODE_VOLUME_UP) upHeld = down;
            else downHeld = down;
            boolean swallow = comboFired;
            if (down && upHeld && downHeld && !comboFired) {
                comboFired = true;
                swallow = true;
                onAssistTrigger();
            }
            if (!upHeld && !downHeld) comboFired = false;
            return swallow;
        }
        if (trig == 2) {
            if (code == KeyEvent.KEYCODE_VOLUME_DOWN && down && e.getRepeatCount() == 0) {
                long now = e.getEventTime();
                if (now - lastVolDown < 400) {
                    lastVolDown = 0;
                    onAssistTrigger();
                    return true;
                }
                lastVolDown = now;
            }
            return false;
        }
        if (trig == 3 && code == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (down && e.getRepeatCount() == 0) {
                holdFired = false;
                main.postDelayed(holdRunnable, 700);
            } else if (!down) {
                main.removeCallbacks(holdRunnable);
                if (holdFired) {
                    holdFired = false;
                    return true;
                }
            }
            return holdFired;
        }
        return false;
    }

    // ================= BubbleLive =================

    private void toggleLive() {
        if (liveOn) stopLive();
        else startLive();
    }

    private void startLive() {
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            say("Нужен микрофон: открой приложение BubbleAI и нажми «3. Разрешить микрофон».", BubbleView.SAD, false);
            return;
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            say("На телефоне нет службы распознавания речи.", BubbleView.SAD, false);
            return;
        }
        liveOn = true;
        hidePanel(true);
        showBubble();
        appendLog("🎙 BubbleLive включён");
        showCaption("🎙 Слушаю…");
        startListening();
    }

    private void stopLive() {
        liveOn = false;
        main.post(new Runnable() {
            @Override
            public void run() {
                if (recognizer != null) {
                    try {
                        recognizer.cancel();
                        recognizer.destroy();
                    } catch (Exception ignored) {
                    }
                    recognizer = null;
                }
            }
        });
        if (tts != null) tts.stop();
        hideCaption();
        appendLog("🎙 BubbleLive выключен");
    }

    private SpeechRecognizer makeRecognizer() {
        SpeechRecognizer sr = null;
        try {
            getPackageManager().getPackageInfo("com.google.android.googlequicksearchbox", 0);
            sr = SpeechRecognizer.createSpeechRecognizer(this, new ComponentName(
                    "com.google.android.googlequicksearchbox",
                    "com.google.android.voicesearch.serviceapi.GoogleRecognitionService"));
        } catch (Exception ignored) {
        }
        if (sr == null) sr = SpeechRecognizer.createSpeechRecognizer(this);
        return sr;
    }

    private final RecognitionListener listener = new RecognitionListener() {
        @Override
        public void onReadyForSpeech(Bundle params) {
        }

        @Override
        public void onBeginningOfSpeech() {
        }

        @Override
        public void onRmsChanged(float rmsdB) {
        }

        @Override
        public void onBufferReceived(byte[] buffer) {
        }

        @Override
        public void onEndOfSpeech() {
        }

        @Override
        public void onError(int error) {
            if (!liveOn) return;
            if (error == SpeechRecognizer.ERROR_NO_MATCH
                    || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
                    || error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                main.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        startListening();
                    }
                }, 400);
            } else {
                liveOn = false;
                hideCaption();
                say("Микрофон не работает (ошибка " + error + ").", BubbleView.SAD, false);
            }
        }

        @Override
        public void onResults(Bundle results) {
            ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (list != null && !list.isEmpty()) {
                String t = list.get(0);
                showCaption("🗣 " + t);
                handleUserText(t, true);
            } else {
                startListening();
            }
        }

        @Override
        public void onPartialResults(Bundle partialResults) {
            ArrayList<String> list = partialResults.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            if (list != null && !list.isEmpty()) showCaption("🗣 " + list.get(0));
        }

        @Override
        public void onEvent(int eventType, Bundle params) {
        }
    };

    private void startListening() {
        main.post(new Runnable() {
            @Override
            public void run() {
                if (!liveOn) return;
                if (busy) {
                    main.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            startListening();
                        }
                    }, 700);
                    return;
                }
                try {
                    if (recognizer == null) {
                        recognizer = makeRecognizer();
                        recognizer.setRecognitionListener(listener);
                    }
                    Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU");
                    i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
                    recognizer.startListening(i);
                    showCaption("🎙 Слушаю…");
                } catch (Exception ex) {
                    liveOn = false;
                    hideCaption();
                    say("Ошибка микрофона: " + ex.getMessage(), BubbleView.SAD, false);
                }
            }
        });
    }

    // ================= BubblePRO =================

    private void openEditor() {
        if (gamePkg == null) {
            say("Сначала открой нужную игру, а потом вызови меня оттуда.", BubbleView.SAD, false);
            return;
        }
        hidePanel(true);
        main.post(new Runnable() {
            @Override
            public void run() {
                editor.show(gamePkg);
            }
        });
    }

    private void startPro(String goalRaw) {
        if (proRunning) return;
        if (busy) {
            appendLog("⏳ Я ещё занят…");
            return;
        }
        if (gamePkg == null) {
            say("Сначала открой игру и вызови меня оттуда.", BubbleView.SAD, false);
            return;
        }
        final String pkg = gamePkg;
        final List<ProStore.Btn> btns = ProStore.load(this, pkg);
        if (btns.isEmpty()) {
            say("Сначала расставь кнопки: нажми «📐 Кнопки» в нужной игре.", BubbleView.SAD, false);
            return;
        }
        final String goal = goalRaw.isEmpty() ? "Играй сам и действуй разумно" : goalRaw;
        final boolean macro = goal.toLowerCase(Locale.ROOT).startsWith("макрос:");
        if (!macro && !bridge.installed()) {
            say("DeepSeek не установлен, а без него я не работаю.", BubbleView.SAD, false);
            return;
        }
        proRunning = true;
        busy = true;
        bridge.abort = false;
        hidePanel(true);
        showBubble();
        setEmotion(BubbleView.HAPPY);
        appendLog("🎮 BubblePRO: " + goal + " (нажми на пузырь, чтобы остановить)");
        worker.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    if (macro) runMacro(goal, btns);
                    else runAiLoop(pkg, goal, btns);
                } catch (Throwable t) {
                    appendLog("⚠ PRO: " + t);
                } finally {
                    proRunning = false;
                    busy = false;
                    say("Закончил играть.", BubbleView.HAPPY, false);
                }
            }
        });
    }

    private void stopPro() {
        proRunning = false;
        bridge.abort = true;
        appendLog("⏹ BubblePRO остановлен");
    }

    private void stopAll() {
        if (proRunning) stopPro();
        if (liveOn) stopLive();
    }

    private void runMacro(String goal, List<ProStore.Btn> btns) {
        String list = goal.substring(goal.indexOf(':') + 1);
        String[] labels = list.split(",");
        while (proRunning) {
            for (String l : labels) {
                if (!proRunning) break;
                pressButton(btns, l.trim());
                Actions.sleep(1200);
            }
        }
    }

    private void runAiLoop(String pkg, String goal, List<ProStore.Btn> btns) {
        StringBuilder hist = new StringBuilder();
        for (int step = 0; step < 300 && proRunning; step++) {
            String screen = bridge.screenText(targetRoot(), 500);
            String raw = askWithCover(Brain.proPrompt(goal, pkg, btns, screen, hist.toString()), "Играю…");
            if (!proRunning) break;
            if (raw == null) {
                say("Остановился: " + bridge.lastError, BubbleView.SAD, false);
                break;
            }
            Brain.Reply r = Brain.parse(raw);
            say(r.say, BubbleView.emotionFromName(r.emotion), false);
            for (String label : r.press) {
                if (!proRunning) break;
                boolean ok = pressButton(btns, label);
                hist.append(label).append(ok ? "" : " (нет такой кнопки)").append(", ");
                Actions.sleep(250);
            }
            if (hist.length() > 200) hist.delete(0, hist.length() - 200);
            if (r.done) break;
            Actions.sleep(Math.max(500, Math.min(r.waitMs, 5000)));
        }
    }

    private boolean pressButton(List<ProStore.Btn> btns, String label) {
        ProStore.Btn found = null;
        String q = label.toLowerCase(Locale.ROOT).trim();
        for (ProStore.Btn b : btns) {
            if (b.label.toLowerCase(Locale.ROOT).equals(q)) {
                found = b;
                break;
            }
        }
        if (found == null && !q.isEmpty()) {
            for (ProStore.Btn b : btns) {
                if (!b.label.isEmpty() && b.label.toLowerCase(Locale.ROOT).contains(q)) {
                    found = b;
                    break;
                }
            }
        }
        if (found == null) {
            try {
                int idx = Integer.parseInt(q) - 1;
                if (idx >= 0 && idx < btns.size()) found = btns.get(idx);
            } catch (NumberFormatException ignored) {
            }
        }
        if (found == null) return false;
        float dist = dp(160);
        switch (found.mode) {
            case 1:
                actions.tap(found.x, found.y, 800);
                break;
            case 2:
                actions.swipe(found.x, found.y, found.x, found.y - dist, 250);
                break;
            case 3:
                actions.swipe(found.x, found.y, found.x, found.y + dist, 250);
                break;
            case 4:
                actions.swipe(found.x, found.y, found.x - dist, found.y, 250);
                break;
            case 5:
                actions.swipe(found.x, found.y, found.x + dist, found.y, 250);
                break;
            default:
                actions.tap(found.x, found.y, 60);
        }
        return true;
    }
}
