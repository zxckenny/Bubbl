package com.bubble.ai;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.service.voice.VoiceInteractionSession;

public class BubbleSession extends VoiceInteractionSession {

    public BubbleSession(Context context) {
        super(context);
    }

    @Override
    public void onShow(Bundle args, int showFlags) {
        super.onShow(args, showFlags);
        BubbleAccessService s = BubbleAccessService.instance;
        if (s != null) {
            s.onAssistTrigger();
        } else {
            Intent i = new Intent(getContext(), MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(i);
        }
        hide();
    }
}
