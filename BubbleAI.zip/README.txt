BubbleAI: сборка APK через GitHub

1. Создай репозиторий на GitHub и загрузи в него ВСЁ содержимое этой папки (включая скрытую папку .github).
   Файл сборки должен лежать по пути: .github/workflows/build.yml
2. Открой вкладку Actions, выбери "Build APK" и нажми Run workflow (или просто сделай push).
3. Когда сборка зелёная, открой её и скачай APK в разделе Artifacts (BubbleAI-debug-apk).
4. Установи APK, открой BubbleAI и пройди шаги 1-4 на главном экране.
